<?php
session_start();

define('DB_SERVER', 'database-1.clomoc0wcmx9.us-east-1.rds.amazonaws.com');
define('DB_USERNAME', 'admin');
define('DB_PASSWORD', 'admin123');
define('DB_DATABASE', 'project');

$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve user input
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Encrypt the password using AES-256 (adjust the key accordingly)
    $key = "12345678901234567890123456789012";
    $encrypted_password = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $key);
    $encrypted_username = openssl_encrypt($username, 'aes-256-cbc', $key, 0, $key);

    // Check login credentials against the database
    $query = "SELECT * FROM users WHERE username = '$encrypted_username' AND hashed_password = '$encrypted_password'";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        // Login successful
        $_SESSION['username'] = $username;
        header("Location: welcome.php"); // Redirect to a welcome page or dashboard
        exit();
    } else {
        // Invalid login credentials
        echo "Invalid username or password.";
    }
}

$conn->close();
?>
