<?php
// Connect to MySQL
$conn = new mysqli("localhost", "root", "", "project");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user input
$username = $_POST['username'];
$password = $_POST['password'];

// Encrypt the password using AES-256
$key = "12345678901234567890123456789012"; // Replace with a strong, unique key
$encrypted_password = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $key);
$encrypted_username = openssl_encrypt($username, 'aes-256-cbc', $key, 0, $key);

// Insert data into the database
$sql = "INSERT INTO users (username, hashed_password) VALUES ('$encrypted_username', '$encrypted_password')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
