<?php

define('DB_SERVER', 'database-1.clomoc0wcmx9.us-east-1.rds.amazonaws.com');
define('DB_USERNAME', 'admin');
define('DB_PASSWORD', 'admin123');
define('DB_DATABASE', 'project');

$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
//$conn = new mysqli("localhost", "root", "", "project");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Perform registration logic here

    // Retrieve user input
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $mobileNumber = $_POST['mobileNumber'];
    $address = $_POST['address'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    //$verifyPassword = $_POST['verifyPassword'];
    $email = $_POST['email'];

    // Validate input (perform additional validation as needed)

    // Check if passwords match
   if ($password !== $verifyPassword) {
        echo "Passwords do not match.";
        exit;
    }

    // Encrypt the password using AES-256
$key = "12345678901234567890123456789012"; // Replace with a strong, unique key
$encrypted_password = openssl_encrypt($password, 'aes-256-cbc', $key, 0, $key);
$encrypted_username = openssl_encrypt($username, 'aes-256-cbc', $key, 0, $key);

// Insert data into the database
$sql = "INSERT INTO users (first_name, last_name, mobile_number, address, username, hashed_password, email) VALUES ('$firstName', '$lastName','$mobileNumber', '$address', '$encrypted_username', '$encrypted_password', '$email')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

    // Perform database insertion (use prepared statements to prevent SQL injection)

    // Redirect to login page
    header("Location: login.php");
    $conn->close();

?>
